package Units;

/**
 * Created by Cathy on 20/03/2016.
 */
public class Time {

    public static void main(String[] args)
    {
       int inSeconds=0, seconds=0,  modMinutes, modSeconds;



    }
}
